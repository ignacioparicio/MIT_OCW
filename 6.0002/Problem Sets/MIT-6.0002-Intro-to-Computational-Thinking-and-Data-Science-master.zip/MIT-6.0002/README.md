# MIT-6.0002-Intro-to-Computational-Thinking-and-Data-Science
The course material can be found here: https://ocw.mit.edu/courses/electrical-engineering-and-computer-science/6-0002-introduction-to-computational-thinking-and-data-science-fall-2016
