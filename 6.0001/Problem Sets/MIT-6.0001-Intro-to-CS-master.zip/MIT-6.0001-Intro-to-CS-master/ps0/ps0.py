import numpy as np
x = int(input('Enter number x: '))
y = int(input('Enter number y: '))
print('X**y =', x**y)
print('log(x) =', np.log2(x))
