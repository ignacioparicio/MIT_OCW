# MIT-6.0001-Intro-to-CS
The course materials can be found here: https://ocw.mit.edu/courses/electrical-engineering-and-computer-science/6-0001-introduction-to-computer-science-and-programming-in-python-fall-2016.
The codes are written in python 3. If you have any questions about my solutions, email me at tuthang102@gmail.com. I'll be happy to answer your questions. Please star if you find this repository helpful. Thank you!
