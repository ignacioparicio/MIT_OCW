# Fall 2012 6.034 Lab 2: Search
#
# Your answers for the true and false questions will be in the following form.  
# Your answers will look like one of the two below:
#ANSWER1 = True
#ANSWER1 = False

# 1: True or false - Hill Climbing search is guaranteed to find a solution
#    if there is a solution
ANSWER1 = None

# 2: True or false - Best-first search will give an optimal search result
#    (shortest path length).
#    (If you don't know what we mean by best-first search, refer to
#     http://courses.csail.mit.edu/6.034f/ai3/ch4.pdf (page 13 of the pdf).)
ANSWER2 = None

# 3: True or false - Best-first search and hill climbing make use of
#    heuristic values of nodes.
ANSWER3 = None

# 4: True or false - A* uses an extended-nodes set.
ANSWER4 = None

# 5: True or false - Breadth first search is guaranteed to return a path
#    with the shortest number of nodes.
ANSWER5 = None

# 6: True or false - The regular branch and bound uses heuristic values
#    to speed up the search for an optimal path.
ANSWER6 = None

# Import the Graph data structure from 'search.py'
# Refer to search.py for documentation
from search import Graph

## Optional Warm-up: BFS and DFS
# If you implement these, the offline tester will test them.
# If you don't, it won't.
# The online tester will not test them.

def bfs(graph, start, goal):
    """
    Finds a path between start and goal node using breadth-first search.

    Parameters:
        graph: Graph
            The graph on which to carry out the search
        start: string
            Node number at which to start
        goal: string
            Node number at which to end

    Returns:
        A list of nodes from start to goal using breadth-first search,
        represented by a list of nodes (in strings), [n_1, n_2, ..., n_k]
        where there exists an edge from n_i to n_(i+1) in graph

        If there exists no path, then returns an empty list
    """
    
    if start == goal:
        return [start]
        
    visited = {start}
    # Agenda is a list of lists; inner lists are different paths being followed
    agenda = [[start]]
    
    while True:
        path = agenda.pop(0)
        node = path [-1]
        
        for dest in graph.get_connected_nodes(node):            
            # Skip nodes already visited
            if dest in visited:
                continue            
            # If goal is reached, return the path
            if dest == goal:
                return path + [goal]
            # Else add 'dest' to 'path' and put it at the end of the agenda
            else:
                visited.add(dest)
                
                '''
                Note that this is the only difference between dfs and bfs with
                the current implementation; dfs adds new paths to the beginning
                of the agenda, bfs to the end
                '''     
                agenda = agenda + [path + [dest]]

    # If goal node is never reached, return an empty list
    return []    
        

## Once you have completed the breadth-first search,
## this part should be very simple to complete.
def dfs(graph, start, goal, agenda = [], path = []):
    """
    Finds a path between start and goal node using depth-first search.

    Parameters:
        graph: Graph
            The graph on which to carry out the search
        start: string
            Node number at which to start
        goal: string
            Node number at which to end

    Returns:
        A list of nodes from start to goal using depth-first search,
        represented by a list of nodes (in strings), [n_1, n_2, ..., n_k]
        where there exists an edge from n_i to n_(i+1) in graph

        If there exists no path, then returns an empty list
    """   
    
    if start == goal:
        return [start]
        
    visited = {start}
    # Agenda is a list of lists; inner lists are different paths being followed
    agenda = [[start]]
    
    while True:
        path = agenda.pop(0)
        node = path [-1]
        
        for dest in graph.get_connected_nodes(node):            
            # Skip nodes already visited
            if dest in visited:
                continue      
            # If goal is reached, return the path
            if dest == goal:
                return path + [goal]
            # Else add 'dest' to 'path' and put it at beginning of the agenda
            else:
                visited.add(dest)
                
                '''
                Note that this is the only difference between dfs and bfs with
                the current implementation; dfs adds new paths to the beginning
                of the agenda, bfs to the end
                '''               
                agenda = [path + [dest]] + agenda

    # If goal node is never reached, return an empty list
    return []    

       
## Now we're going to add some heuristics into the search.  
## Remember that hill-climbing is a modified version of depth-first search.
## Search direction should be towards lower heuristic values to the goal.
def hill_climbing(graph, start, goal):
    """
    Finds a path between start and goal node using depth-first search.

    Parameters:
        graph: Graph
            The graph on which to carry out the search
        start: string
            Node number at which to start
        goal: string
            Node number at which to end

    Returns:
        A list of nodes from start to goal using depth-first search,
        represented by a list of nodes (in strings), [n_1, n_2, ..., n_k]
        where there exists an edge from n_i to n_(i+1) in graph

        If there exists no path, then returns an empty list
    """   
    
    if start == goal:
        return [start]
        
    # Agenda is a list of lists; inner lists are different paths being followed
    agenda = [[start]]
    # Set of invalid paths to avoid ending up in local heuristic minima
    invalid_paths = []
    
    while True:
        # Build dictionary of index of path -> heuristic
        heuristic_dict = {}
        for i in range(len(agenda)):
                heuristic_dict[i] = graph.get_heuristic(agenda[i][-1], goal)
        # Get a indices in the agenda sorted by heurictic (low -> high)
        sorted_indices = sorted(heuristic_dict, key = heuristic_dict.get)
        # Build sorted agenda
        sorted_agenda = [agenda[i] for i in sorted_indices]
        agenda = sorted_agenda
        # Get path with minimum heuristic, i.e. 'closest to goal'
        path = agenda[0]
        node = path[-1]
        
        invalid_path = True
        for dest in graph.get_connected_nodes(node):                
            # If goal is reached, return the path
            if dest == goal:
                return path + [goal]
            # Skip nodes in path
            if dest in path:
                continue
            # Skip if it leads to a path already explored
            if path + [dest] in agenda:
                continue
            # Skip invalid paths
            if (path + [dest]) in invalid_paths:
                continue
            # Else add 'dest' to 'path' and the path back in the agenda
            else:
                '''
                Note that this is the only difference between dfs and bfs with
                the current implementation; dfs adds new paths to the beginning
                of the agenda, bfs to the end
                '''               
                agenda += [path + [dest]]
                invalid_path = False
                break
            
        # If this point is reached, no node gets to a better heuristic
        # and hence we are trapped in an infinite loop. This is an invalid 
        if invalid_path:
            invalid_paths.append(path)
            agenda.pop(0)

    # If goal node is never reached, return an empty list
    return []

from graphs import *
#print(hill_climbing(NEWGRAPH1, 'S', 'G')) 
print(hill_climbing(NEWGRAPH1, 'F', 'G'))    
#print(hill_climbing(NEWGRAPH1, 'H', 'G')) 
print(NEWGRAPH1.get_connected_nodes('A'))

## Now we're going to implement beam search, a variation on BFS
## that caps the amount of memory used to store paths.  Remember,
## we maintain only k candidate paths of length n in our agenda at any time.
## The k top candidates are to be determined using the 
## graph get_heuristic function, with lower values being better values.
def beam_search(graph, start, goal, beam_width):
    raise NotImplementedError

## Now we're going to try optimal search.  The previous searches haven't
## used edge distances in the calculation.

## This function takes in a graph and a list of node names, and returns
## the sum of edge lengths along the path -- the total distance in the path.
def path_length(graph, node_names):
    raise NotImplementedError


def branch_and_bound(graph, start, goal):
    raise NotImplementedError

def a_star(graph, start, goal):
    raise NotImplementedError


## It's useful to determine if a graph has a consistent and admissible
## heuristic.  You've seen graphs with heuristics that are
## admissible, but not consistent.  Have you seen any graphs that are
## consistent, but not admissible?

def is_admissible(graph, goal):
    raise NotImplementedError

def is_consistent(graph, goal):
    raise NotImplementedError

HOW_MANY_HOURS_THIS_PSET_TOOK = ''
WHAT_I_FOUND_INTERESTING = ''
WHAT_I_FOUND_BORING = ''
