var searchData=
[
  ['old_5fsenator_5fclassified',['old_senator_classified',['../namespacelab4.html#a085a485c7a948fb548fb294216b560bc',1,'lab4']]],
  ['old_5fsenator_5fclassified_5fgetargs',['old_senator_classified_getargs',['../namespacetests.html#a817ad020cbf0a5aadfd994ae0454d35f',1,'tests']]]
];
