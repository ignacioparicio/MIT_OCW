var searchData=
[
  ['or',['OR',['../classproduction_1_1_o_r.html',1,'production']]]
];
