var searchData=
[
  ['nearest_5fneighbors',['nearest_neighbors',['../namespaceclassify.html#a38d3402082141a678096dddcb5d6fd02',1,'classify']]],
  ['num_5fchildren',['num_children',['../classtree__searcher_1_1_node.html#a20a00b8d92aae1ffbb7c4ec70836777c',1,'tree_searcher::Node']]],
  ['num_5ftokens_5fon_5fboard',['num_tokens_on_board',['../classconnectfour_1_1_connect_four_board.html#a28425f26b3b7d7857d90a01c9ebe99d7',1,'connectfour::ConnectFourBoard']]]
];
