var searchData=
[
  ['classify',['classify',['../namespaceclassify.html',1,'']]],
  ['connectfour',['connectfour',['../namespaceconnectfour.html',1,'']]],
  ['csp',['csp',['../namespacecsp.html',1,'']]]
];
