var searchData=
[
  ['legislator_5finfo',['legislator_info',['../namespacedata__reader.html#ae6d7a3d1c3644c57a762604d7521784f',1,'data_reader']]],
  ['limit_5fvotes',['limit_votes',['../namespacedata__reader.html#ab91ea6523c4ca764fb49f9fdfb1789cb',1,'data_reader']]],
  ['limited_5fhouse_5fclassifier',['limited_house_classifier',['../namespacelab4.html#afeb6f3043e63aad7e472bc70ac32b8cc',1,'lab4']]],
  ['longest_5fchain',['longest_chain',['../classconnectfour_1_1_connect_four_board.html#aae7f90bbc3ec64b4f8b6edb60584eaf9',1,'connectfour::ConnectFourBoard']]]
];
