var searchData=
[
  ['data_5freader_2epy',['data_reader.py',['../data__reader_8py.html',1,'']]]
];
