var searchData=
[
  ['unextended',['UNEXTENDED',['../classcsp_1_1_node.html#adb2acf3476fbb84b27a669067cef8c53',1,'csp::Node']]]
];
