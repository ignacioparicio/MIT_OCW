var searchData=
[
  ['uniq',['uniq',['../namespaceproduction.html#aaa6f4f50810b5cf264bd619fe117ecd1',1,'production']]],
  ['unit_5fvector',['unit_vector',['../namespacemat__vec__ops.html#a7f771c61cafe041032f06e9911865dec',1,'mat_vec_ops']]]
];
