var searchData=
[
  ['search',['search',['../namespacesearch.html',1,'']]],
  ['sudoku_5fcsp',['sudoku_csp',['../namespacesudoku__csp.html',1,'']]]
];
