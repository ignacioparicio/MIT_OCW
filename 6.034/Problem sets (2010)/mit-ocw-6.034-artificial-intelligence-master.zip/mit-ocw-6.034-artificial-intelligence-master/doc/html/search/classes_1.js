var searchData=
[
  ['binaryconstraint',['BinaryConstraint',['../classcsp_1_1_binary_constraint.html',1,'csp']]]
];
