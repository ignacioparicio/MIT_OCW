var searchData=
[
  ['search_2epy',['search.py',['../search_8py.html',1,'']]],
  ['sudoku_5fcsp_2epy',['sudoku_csp.py',['../sudoku__csp_8py.html',1,'']]]
];
