var searchData=
[
  ['infinity',['INFINITY',['../namespaceutil.html#a7eb14c55451b00b740e7a1f68099e86d',1,'util.INFINITY()'],['../namespaceclassify.html#a065cd3de81830bc79376bb6be8b41487',1,'classify.INFINITY()']]]
];
