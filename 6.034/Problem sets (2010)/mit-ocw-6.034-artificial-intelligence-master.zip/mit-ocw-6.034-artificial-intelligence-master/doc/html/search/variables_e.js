var searchData=
[
  ['quick_5fto_5fwin_5fplayer',['quick_to_win_player',['../namespacelab3.html#aa43b2937a5bad423a493276473384d9a',1,'lab3']]]
];
