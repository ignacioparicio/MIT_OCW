var searchData=
[
  ['algebra_2epy',['algebra.py',['../algebra_8py.html',1,'']]],
  ['algebra_5futils_2epy',['algebra_utils.py',['../algebra__utils_8py.html',1,'']]]
];
