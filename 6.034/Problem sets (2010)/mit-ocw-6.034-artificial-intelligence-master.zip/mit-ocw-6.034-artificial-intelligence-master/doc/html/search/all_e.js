var searchData=
[
  ['old_5fsenator_5fclassified',['old_senator_classified',['../namespacelab4.html#a085a485c7a948fb548fb294216b560bc',1,'lab4']]],
  ['old_5fsenator_5fclassified_5fgetargs',['old_senator_classified_getargs',['../namespacetests.html#a817ad020cbf0a5aadfd994ae0454d35f',1,'tests']]],
  ['old_5fsenator_5fclassified_5ftestanswer',['old_senator_classified_testanswer',['../namespacetests.html#ae16823a8133ee9d2483fb0a110e89f35',1,'tests']]],
  ['or',['OR',['../classproduction_1_1_o_r.html',1,'production']]]
];
