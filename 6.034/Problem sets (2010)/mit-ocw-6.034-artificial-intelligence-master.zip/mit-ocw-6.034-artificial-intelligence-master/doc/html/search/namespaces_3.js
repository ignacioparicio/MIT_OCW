var searchData=
[
  ['data_5freader',['data_reader',['../namespacedata__reader.html',1,'']]]
];
