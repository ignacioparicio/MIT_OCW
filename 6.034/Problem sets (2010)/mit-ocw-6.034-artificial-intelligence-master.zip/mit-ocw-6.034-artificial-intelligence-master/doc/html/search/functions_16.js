var searchData=
[
  ['what_5fi_5ffound_5fboring_5ftestanswer',['WHAT_I_FOUND_BORING_testanswer',['../namespacetests.html#a13f88cd85ed586d95912e20ea25a5745',1,'tests']]],
  ['what_5fi_5ffound_5finteresting_5ftestanswer',['WHAT_I_FOUND_INTERESTING_testanswer',['../namespacetests.html#ad0f0f17aefd4844393d9db636b4124ac',1,'tests']]]
];
