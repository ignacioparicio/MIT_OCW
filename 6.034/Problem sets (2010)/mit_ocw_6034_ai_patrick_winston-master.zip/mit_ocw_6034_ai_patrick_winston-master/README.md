# mit_ocw_6034_ai_patrick_winston

Solution to all problem sets of Patric Winston's 6.034 Introduction to artificial intelligence accesible through MIT OpenCourseware.

I must admit that there are some problems sets I had difficulties with, and only solved half-heartedly, but about 80% of all assignments should be solved well. I usually do a second or third pass working on those difficult/half-hearted problem sets, but decided here that it was more useful working on Andrew Ng's Machine Learning course on coursera rather than doing a second pass, as this course is not exactly what I was looking for regarding practical education for machine learning systems. I really enjoyed this course though, many thanks to MIT OCW and Patrick Winston who have made this experience possible!!