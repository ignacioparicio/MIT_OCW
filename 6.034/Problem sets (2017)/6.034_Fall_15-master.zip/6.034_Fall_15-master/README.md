# 6.034_Fall_15
Python codes for 6.034 Artificial Intelligence 15'
Implemented projects include Forward & Backward Chaining, Searching, Minimax with Alpha-beta Optimization, Belief Propagation, Identification Trees, Neural Nets and Adaboost.
